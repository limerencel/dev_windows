#ifndef WINDOW_CONFIG_H
#define WINDOW_CONFIG_H

const int WINDOW_WIDTH = 1600;
const int WINDOW_HEIGHT = 800;
const int LIMITATION = 10;

#endif // WINDOW_CONFIG_H
